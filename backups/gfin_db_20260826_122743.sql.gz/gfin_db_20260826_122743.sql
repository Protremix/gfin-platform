--
-- PostgreSQL database dump
--

\restrict wEVkWbpteLD2dCbkTxlrJshMAm6OaJeDeLQHUM4Xg6zdwOyfwtwr0c1GrpiuLJf

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict wEVkWbpteLD2dCbkTxlrJshMAm6OaJeDeLQHUM4Xg6zdwOyfwtwr0c1GrpiuLJf

