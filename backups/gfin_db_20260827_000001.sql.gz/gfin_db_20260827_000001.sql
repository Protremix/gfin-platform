--
-- PostgreSQL database dump
--

\restrict 62ZD04CUcag18hZX8pMLKEVnEo0gozHmg9XRpcJAcb9qW7zgD9sNFIX3NG4eAWT

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alerts; Type: TABLE; Schema: public; Owner: gfin
--

CREATE TABLE public.alerts (
    id integer NOT NULL,
    alert_id text NOT NULL,
    case_id text NOT NULL,
    country text NOT NULL,
    level text NOT NULL,
    message text,
    next_action text,
    police_contact text,
    delivery_status text DEFAULT 'PENDING'::text,
    delivery_timestamp timestamp with time zone,
    routed_from text DEFAULT 'GFIN_AUTOMATED_ROUTING'::text,
    target text,
    created_date timestamp with time zone DEFAULT now()
);


ALTER TABLE public.alerts OWNER TO gfin;

--
-- Name: alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: gfin
--

CREATE SEQUENCE public.alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.alerts_id_seq OWNER TO gfin;

--
-- Name: alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gfin
--

ALTER SEQUENCE public.alerts_id_seq OWNED BY public.alerts.id;


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: gfin
--

CREATE TABLE public.api_keys (
    id integer NOT NULL,
    key_hash text NOT NULL,
    agency text NOT NULL,
    jurisdiction text,
    scope text[],
    is_active boolean DEFAULT true,
    created_date timestamp with time zone DEFAULT now()
);


ALTER TABLE public.api_keys OWNER TO gfin;

--
-- Name: api_keys_id_seq; Type: SEQUENCE; Schema: public; Owner: gfin
--

CREATE SEQUENCE public.api_keys_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.api_keys_id_seq OWNER TO gfin;

--
-- Name: api_keys_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gfin
--

ALTER SEQUENCE public.api_keys_id_seq OWNED BY public.api_keys.id;


--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: gfin
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    case_id text,
    action text,
    actor text,
    tool text,
    query text,
    result text,
    evidence_id text,
    "timestamp" timestamp with time zone DEFAULT now()
);


ALTER TABLE public.audit_log OWNER TO gfin;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: gfin
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_log_id_seq OWNER TO gfin;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gfin
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: cases; Type: TABLE; Schema: public; Owner: gfin
--

CREATE TABLE public.cases (
    id integer NOT NULL,
    case_id text NOT NULL,
    status text DEFAULT 'INVESTIGATING'::text,
    target text,
    target_type text,
    trigger text DEFAULT 'PUBLIC_REPORT'::text,
    summary text,
    subject_reason text,
    classification text DEFAULT 'LAW ENFORCEMENT SENSITIVE'::text,
    accusation_level text,
    confidence real DEFAULT 0.0,
    scam_patterns text[],
    scam_indicators jsonb DEFAULT '[]'::jsonb,
    affected_countries text[],
    routed_to_countries text[],
    physical_locations jsonb DEFAULT '[]'::jsonb,
    financial_indicators jsonb DEFAULT '[]'::jsonb,
    digital_identifiers jsonb DEFAULT '[]'::jsonb,
    evidence_chain jsonb DEFAULT '[]'::jsonb,
    victim_count integer DEFAULT 0,
    victim_loss text,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now()
);


ALTER TABLE public.cases OWNER TO gfin;

--
-- Name: cases_id_seq; Type: SEQUENCE; Schema: public; Owner: gfin
--

CREATE SEQUENCE public.cases_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cases_id_seq OWNER TO gfin;

--
-- Name: cases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gfin
--

ALTER SEQUENCE public.cases_id_seq OWNED BY public.cases.id;


--
-- Name: complaint_files; Type: TABLE; Schema: public; Owner: gfin
--

CREATE TABLE public.complaint_files (
    id integer NOT NULL,
    complaint_ref text NOT NULL,
    filename text NOT NULL,
    filepath text NOT NULL,
    file_hash text NOT NULL,
    file_size integer,
    mime_type text,
    uploaded_date timestamp with time zone DEFAULT now()
);


ALTER TABLE public.complaint_files OWNER TO gfin;

--
-- Name: complaint_files_id_seq; Type: SEQUENCE; Schema: public; Owner: gfin
--

CREATE SEQUENCE public.complaint_files_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.complaint_files_id_seq OWNER TO gfin;

--
-- Name: complaint_files_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gfin
--

ALTER SEQUENCE public.complaint_files_id_seq OWNED BY public.complaint_files.id;


--
-- Name: country_routing; Type: TABLE; Schema: public; Owner: gfin
--

CREATE TABLE public.country_routing (
    id integer NOT NULL,
    country_code text NOT NULL,
    country_name text NOT NULL,
    contacts jsonb DEFAULT '[]'::jsonb,
    europol_contact text,
    interpol_contact text,
    languages text[],
    timezone text
);


ALTER TABLE public.country_routing OWNER TO gfin;

--
-- Name: country_routing_id_seq; Type: SEQUENCE; Schema: public; Owner: gfin
--

CREATE SEQUENCE public.country_routing_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.country_routing_id_seq OWNER TO gfin;

--
-- Name: country_routing_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gfin
--

ALTER SEQUENCE public.country_routing_id_seq OWNED BY public.country_routing.id;


--
-- Name: evidence; Type: TABLE; Schema: public; Owner: gfin
--

CREATE TABLE public.evidence (
    id integer NOT NULL,
    case_id text NOT NULL,
    evidence_id text NOT NULL,
    phase text,
    finding text,
    source_provider text,
    source_url text,
    source_type text,
    confidence text DEFAULT 'MEDIUM'::text,
    content_hash text,
    "timestamp" timestamp with time zone DEFAULT now(),
    created_date timestamp with time zone DEFAULT now()
);


ALTER TABLE public.evidence OWNER TO gfin;

--
-- Name: evidence_id_seq; Type: SEQUENCE; Schema: public; Owner: gfin
--

CREATE SEQUENCE public.evidence_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.evidence_id_seq OWNER TO gfin;

--
-- Name: evidence_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gfin
--

ALTER SEQUENCE public.evidence_id_seq OWNED BY public.evidence.id;


--
-- Name: people; Type: TABLE; Schema: public; Owner: gfin
--

CREATE TABLE public.people (
    id integer NOT NULL,
    case_id text NOT NULL,
    role text NOT NULL,
    name text NOT NULL,
    entity_type text,
    details text,
    is_verified boolean DEFAULT false,
    source text,
    confidence text DEFAULT 'UNVERIFIED'::text,
    created_date timestamp with time zone DEFAULT now()
);


ALTER TABLE public.people OWNER TO gfin;

--
-- Name: people_id_seq; Type: SEQUENCE; Schema: public; Owner: gfin
--

CREATE SEQUENCE public.people_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.people_id_seq OWNER TO gfin;

--
-- Name: people_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gfin
--

ALTER SEQUENCE public.people_id_seq OWNED BY public.people.id;


--
-- Name: police_officers; Type: TABLE; Schema: public; Owner: gfin
--

CREATE TABLE public.police_officers (
    id integer NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    role text DEFAULT 'investigator'::text NOT NULL,
    agency text NOT NULL,
    country_code text NOT NULL,
    password_hash text NOT NULL,
    badge_number text,
    is_active boolean DEFAULT true,
    created_date timestamp with time zone DEFAULT now(),
    last_login timestamp with time zone,
    approved_by text DEFAULT 'SYSTEM'::text
);


ALTER TABLE public.police_officers OWNER TO gfin;

--
-- Name: police_officers_id_seq; Type: SEQUENCE; Schema: public; Owner: gfin
--

CREATE SEQUENCE public.police_officers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.police_officers_id_seq OWNER TO gfin;

--
-- Name: police_officers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gfin
--

ALTER SEQUENCE public.police_officers_id_seq OWNED BY public.police_officers.id;


--
-- Name: scam_websites; Type: TABLE; Schema: public; Owner: gfin
--

CREATE TABLE public.scam_websites (
    id integer NOT NULL,
    domain character varying(255) NOT NULL,
    scam_type character varying(100),
    risk_level character varying(50),
    report_count integer DEFAULT 1,
    first_reported timestamp with time zone DEFAULT now(),
    last_reported timestamp with time zone DEFAULT now(),
    sources text[],
    evidence_hashes text[],
    description text,
    status character varying(50) DEFAULT 'ACTIVE'::character varying,
    target_type character varying(50) DEFAULT 'domain'::character varying,
    related_domains text[],
    wallet_addresses text[],
    phone_numbers text[],
    countries_affected text[],
    total_loss_reported numeric(15,2) DEFAULT 0,
    is_verified boolean DEFAULT false,
    verified_by character varying(255),
    verified_at timestamp with time zone,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now()
);


ALTER TABLE public.scam_websites OWNER TO gfin;

--
-- Name: scam_websites_id_seq; Type: SEQUENCE; Schema: public; Owner: gfin
--

CREATE SEQUENCE public.scam_websites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.scam_websites_id_seq OWNER TO gfin;

--
-- Name: scam_websites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gfin
--

ALTER SEQUENCE public.scam_websites_id_seq OWNED BY public.scam_websites.id;


--
-- Name: search_cache; Type: TABLE; Schema: public; Owner: gfin
--

CREATE TABLE public.search_cache (
    id integer NOT NULL,
    query_hash text NOT NULL,
    query text,
    results jsonb,
    connector text,
    created_date timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone
);


ALTER TABLE public.search_cache OWNER TO gfin;

--
-- Name: search_cache_id_seq; Type: SEQUENCE; Schema: public; Owner: gfin
--

CREATE SEQUENCE public.search_cache_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.search_cache_id_seq OWNER TO gfin;

--
-- Name: search_cache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gfin
--

ALTER SEQUENCE public.search_cache_id_seq OWNED BY public.search_cache.id;


--
-- Name: victim_complaints; Type: TABLE; Schema: public; Owner: gfin
--

CREATE TABLE public.victim_complaints (
    id integer NOT NULL,
    reference_number text NOT NULL,
    victim_id integer NOT NULL,
    case_id text,
    scam_type text NOT NULL,
    target text NOT NULL,
    incident_date date,
    financial_loss text,
    description text,
    investigation_stage text DEFAULT 'RECEIVED'::text,
    country text,
    auto_investigation_started boolean DEFAULT false,
    created_date timestamp with time zone DEFAULT now(),
    updated_date timestamp with time zone DEFAULT now()
);


ALTER TABLE public.victim_complaints OWNER TO gfin;

--
-- Name: victim_complaints_id_seq; Type: SEQUENCE; Schema: public; Owner: gfin
--

CREATE SEQUENCE public.victim_complaints_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.victim_complaints_id_seq OWNER TO gfin;

--
-- Name: victim_complaints_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gfin
--

ALTER SEQUENCE public.victim_complaints_id_seq OWNED BY public.victim_complaints.id;


--
-- Name: victim_notifications; Type: TABLE; Schema: public; Owner: gfin
--

CREATE TABLE public.victim_notifications (
    id integer NOT NULL,
    complaint_ref text NOT NULL,
    victim_id integer NOT NULL,
    message text NOT NULL,
    from_agency text DEFAULT 'GFIN System'::text,
    is_read boolean DEFAULT false,
    created_date timestamp with time zone DEFAULT now()
);


ALTER TABLE public.victim_notifications OWNER TO gfin;

--
-- Name: victim_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: gfin
--

CREATE SEQUENCE public.victim_notifications_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.victim_notifications_id_seq OWNER TO gfin;

--
-- Name: victim_notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gfin
--

ALTER SEQUENCE public.victim_notifications_id_seq OWNED BY public.victim_notifications.id;


--
-- Name: victim_sessions; Type: TABLE; Schema: public; Owner: gfin
--

CREATE TABLE public.victim_sessions (
    token text NOT NULL,
    victim_id integer NOT NULL,
    created_date timestamp with time zone DEFAULT now(),
    expires_at timestamp with time zone
);


ALTER TABLE public.victim_sessions OWNER TO gfin;

--
-- Name: victims; Type: TABLE; Schema: public; Owner: gfin
--

CREATE TABLE public.victims (
    id integer NOT NULL,
    email text NOT NULL,
    name text NOT NULL,
    password_hash text NOT NULL,
    country text,
    phone text,
    is_verified boolean DEFAULT false,
    created_date timestamp with time zone DEFAULT now()
);


ALTER TABLE public.victims OWNER TO gfin;

--
-- Name: victims_id_seq; Type: SEQUENCE; Schema: public; Owner: gfin
--

CREATE SEQUENCE public.victims_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.victims_id_seq OWNER TO gfin;

--
-- Name: victims_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: gfin
--

ALTER SEQUENCE public.victims_id_seq OWNED BY public.victims.id;


--
-- Name: alerts id; Type: DEFAULT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.alerts ALTER COLUMN id SET DEFAULT nextval('public.alerts_id_seq'::regclass);


--
-- Name: api_keys id; Type: DEFAULT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.api_keys ALTER COLUMN id SET DEFAULT nextval('public.api_keys_id_seq'::regclass);


--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Name: cases id; Type: DEFAULT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.cases ALTER COLUMN id SET DEFAULT nextval('public.cases_id_seq'::regclass);


--
-- Name: complaint_files id; Type: DEFAULT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.complaint_files ALTER COLUMN id SET DEFAULT nextval('public.complaint_files_id_seq'::regclass);


--
-- Name: country_routing id; Type: DEFAULT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.country_routing ALTER COLUMN id SET DEFAULT nextval('public.country_routing_id_seq'::regclass);


--
-- Name: evidence id; Type: DEFAULT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.evidence ALTER COLUMN id SET DEFAULT nextval('public.evidence_id_seq'::regclass);


--
-- Name: people id; Type: DEFAULT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.people ALTER COLUMN id SET DEFAULT nextval('public.people_id_seq'::regclass);


--
-- Name: police_officers id; Type: DEFAULT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.police_officers ALTER COLUMN id SET DEFAULT nextval('public.police_officers_id_seq'::regclass);


--
-- Name: scam_websites id; Type: DEFAULT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.scam_websites ALTER COLUMN id SET DEFAULT nextval('public.scam_websites_id_seq'::regclass);


--
-- Name: search_cache id; Type: DEFAULT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.search_cache ALTER COLUMN id SET DEFAULT nextval('public.search_cache_id_seq'::regclass);


--
-- Name: victim_complaints id; Type: DEFAULT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.victim_complaints ALTER COLUMN id SET DEFAULT nextval('public.victim_complaints_id_seq'::regclass);


--
-- Name: victim_notifications id; Type: DEFAULT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.victim_notifications ALTER COLUMN id SET DEFAULT nextval('public.victim_notifications_id_seq'::regclass);


--
-- Name: victims id; Type: DEFAULT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.victims ALTER COLUMN id SET DEFAULT nextval('public.victims_id_seq'::regclass);


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: gfin
--

COPY public.alerts (id, alert_id, case_id, country, level, message, next_action, police_contact, delivery_status, delivery_timestamp, routed_from, target, created_date) FROM stdin;
1	ALERT-REAL-001	GFIN-CASE-001	GB	CRITICAL	cncintelinfo.com — brand impersonation. 50+ domains. UK + ES victims. $35K+ losses.	Action Fraud should review full report.	reports@actionfraud.police.uk	PENDING	\N	GFIN_AUTOMATED_ROUTING	cncintelinfo.com	2026-08-26 19:31:43.999879+00
2	ALERT-REAL-002	GFIN-CASE-001	ES	HIGH	Spanish victims targeted by fake CNC Intelligence recovery scam.	Policía Nacional should investigate.	denuncias.policia@policia.es	PENDING	\N	GFIN_AUTOMATED_ROUTING	cncintelinfo.com	2026-08-26 19:31:44.000887+00
3	ALERT-REAL-003	GFIN-CASE-001	DE	MEDIUM	cncintelltd.com hosted on SEDO GmbH in Munich.	BKA should note infrastructure lead.	cybercrime@bka.de	PENDING	\N	GFIN_AUTOMATED_ROUTING	cncintelltd.com	2026-08-26 19:31:44.001412+00
4	ALERT-REAL-004	GFIN-CASE-001	EUROPOL	CRITICAL	CROSS-BORDER: CNC Intelligence network affects GB+ES+DE. FBI-seized Payback LTD connected.	Europol ECCC should coordinate.		PENDING	\N	GFIN_AUTOMATED_ROUTING	cncintelinfo.com	2026-08-26 19:31:44.001898+00
5	ALERT-REAL-005	GFIN-CASE-001	INTERPOL	HIGH	CROSS-BORDER: FBI seized connected sites. 50+ domains.	INTERPOL should coordinate with FBI.		PENDING	\N	GFIN_AUTOMATED_ROUTING	cncintelinfo.com	2026-08-26 19:31:44.0023+00
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: gfin
--

COPY public.api_keys (id, key_hash, agency, jurisdiction, scope, is_active, created_date) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: gfin
--

COPY public.audit_log (id, case_id, action, actor, tool, query, result, evidence_id, "timestamp") FROM stdin;
1	\N	COMPLAINT_FILED	victim:1	victim_portal	fake-recovery-site.com	Ref: GFIN-2026-6583E9A8, Type: RECOVERY_SCAM, Files: 0	\N	2026-08-26 19:32:03.007395+00
4	\N	COMPLAINT_FILED	victim:2	victim_portal	scam-recovery-experts.com	Ref: GFIN-2026-DC2A7FC8, Type: RECOVERY_SCAM, Files: 0	\N	2026-08-26 19:40:08.342856+00
5	\N	COMPLAINT_FILED	victim:3	victim_portal	scam-recovery-experts.com	Ref: GFIN-2026-2B21593B, Type: RECOVERY_SCAM, Files: 0	\N	2026-08-26 19:40:53.176289+00
6	\N	COMPLAINT_FILED	victim:4	victim_portal	scam-recovery-experts.com	Ref: GFIN-2026-31398B1B, Type: RECOVERY_SCAM, Files: 0	\N	2026-08-26 19:43:06.865418+00
7	\N	COMPLAINT_FILED	victim:5	victim_portal	scam-recovery-experts.com	Ref: GFIN-2026-2CC0A0CC, Type: RECOVERY_SCAM, Files: 0	\N	2026-08-26 19:43:36.628747+00
10	\N	COMPLAINT_FILED	victim:6	victim_portal	fake-crypto-recovery.com	Ref: GFIN-2026-26E2C08F, Type: RECOVERY_SCAM, Files: 0	\N	2026-08-26 20:11:53.395345+00
11	GFIN-AUTO-1787775113	AUTO_INVESTIGATION_STARTED	GFIN_SCAM_ENGINE	local_detection	fake-crypto-recovery.com	Risk: CRITICAL (1.0), Patterns: 4	\N	2026-08-26 20:11:53.42692+00
12	GFIN-AUTO-1787775113	AUTO_INVESTIGATION_COMPLETE	GFIN_SCAM_ENGINE	full_pipeline	fake-crypto-recovery.com	Evidence: 6 items, Risk: CRITICAL, Stage: ROUTED_TO_POLICE	\N	2026-08-26 20:12:13.42554+00
13	SYSTEM	POLICE_REGISTER	admin@gfin-system.com	AUTH	GFIN Central	OFFICER_ID=1, ROLE=admin	\N	2026-08-26 20:21:05.203731+00
14	SYSTEM	POLICE_LOGIN	admin@gfin-system.com	AUTH	127.0.0.1	SUCCESS	\N	2026-08-26 20:21:05.244053+00
15	SYSTEM	POLICE_LOGIN	admin@gfin-system.com	AUTH	127.0.0.1	SUCCESS	\N	2026-08-26 21:45:01.553447+00
16	SYSTEM	POLICE_LOGIN	admin@gfin-system.com	AUTH	127.0.0.1	SUCCESS	\N	2026-08-26 21:58:36.108345+00
17	SYSTEM	POLICE_LOGIN	admin@gfin-system.com	AUTH	178.237.230.37	SUCCESS	\N	2026-08-26 22:00:09.63917+00
18	SYSTEM	POLICE_LOGIN	admin@gfin-system.com	AUTH	178.237.230.37	SUCCESS	\N	2026-08-26 22:00:31.078843+00
19	SYSTEM	POLICE_LOGIN	admin@gfin-system.com	AUTH	47.63.86.107	SUCCESS	\N	2026-08-26 22:02:45.604041+00
20	SYSTEM	POLICE_LOGIN	admin@gfin-system.com	AUTH	127.0.0.1	SUCCESS	\N	2026-08-26 22:03:15.704279+00
21	SYSTEM	POLICE_LOGIN	admin@gfin-system.com	AUTH	178.237.230.37	SUCCESS	\N	2026-08-26 22:03:48.781306+00
22	SYSTEM	POLICE_LOGIN	admin@gfin-system.com	AUTH	47.63.86.107	SUCCESS	\N	2026-08-26 22:04:22.786149+00
23	SYSTEM	POLICE_LOGIN	admin@gfin-system.com	AUTH	127.0.0.1	SUCCESS	\N	2026-08-26 22:05:17.179371+00
24	SYSTEM	POLICE_LOGIN	admin@gfin-system.com	AUTH	127.0.0.1	SUCCESS	\N	2026-08-26 22:16:07.217891+00
25	SYSTEM	POLICE_LOGIN	admin@gfin-system.com	AUTH	127.0.0.1	SUCCESS	\N	2026-08-26 22:16:07.264459+00
26	SYSTEM	POLICE_LOGIN	admin@gfin-system.com	AUTH	86.127.228.7	SUCCESS	\N	2026-08-26 22:16:43.16355+00
27	SYSTEM	POLICE_LOGIN	admin@gfin-system.com	AUTH	127.0.0.1	SUCCESS	\N	2026-08-26 22:24:30.161116+00
28	SYSTEM	POLICE_LOGIN	admin@gfin-system.com	AUTH	178.237.230.37	SUCCESS	\N	2026-08-26 22:25:39.141496+00
29	SYSTEM	POLICE_LOGIN	admin@gfin-system.com	AUTH	83.43.252.51	SUCCESS	\N	2026-08-26 22:29:20.018085+00
\.


--
-- Data for Name: cases; Type: TABLE DATA; Schema: public; Owner: gfin
--

COPY public.cases (id, case_id, status, target, target_type, trigger, summary, subject_reason, classification, accusation_level, confidence, scam_patterns, scam_indicators, affected_countries, routed_to_countries, physical_locations, financial_indicators, digital_identifiers, evidence_chain, victim_count, victim_loss, created_date, updated_date) FROM stdin;
1	GFIN-CASE-001	INVESTIGATING	cncintelinfo.com	DOMAIN	PUBLIC_REPORT	Large-scale brand impersonation campaign targeting CNC Intelligence Inc. 50+ fraudulent domains since June 2024.	\N	LAW ENFORCEMENT SENSITIVE	REQUIRES_INVESTIGATION	0.8	{BRAND_IMPERSONATION,RECOVERY_SCAM,EMAIL_PHISHING}	[]	{GB,ES,DE}	{GB,ES,DE,EUROPOL,INTERPOL}	[]	[]	[]	[]	3	$35,000+	2026-08-26 19:31:43.991977+00	2026-08-26 19:31:43.991977+00
\.


--
-- Data for Name: complaint_files; Type: TABLE DATA; Schema: public; Owner: gfin
--

COPY public.complaint_files (id, complaint_ref, filename, filepath, file_hash, file_size, mime_type, uploaded_date) FROM stdin;
\.


--
-- Data for Name: country_routing; Type: TABLE DATA; Schema: public; Owner: gfin
--

COPY public.country_routing (id, country_code, country_name, contacts, europol_contact, interpol_contact, languages, timezone) FROM stdin;
2	ES	Spain	["Policía Nacional", "Guardia Civil TECO"]			{es}	Europe/Madrid
3	DE	Germany	["BKA Cybercrime", "LKA"]			{de}	Europe/Berlin
4	EUROPOL	Europol ECCC	["European Cyber Crime Centre"]			{en}	Europe/Amsterdam
5	INTERPOL	INTERPOL	["Cybercrime Directorate"]			{en,fr}	Europe/Paris
6	AL	Albania	[{"name": "Cybercrime Sector", "email": "cybercrime@asp.gov.al", "agency": "Albanian State Police"}]	\N	interpol.tirane@asp.gov.al	{Albanian,English}	Europe/Tirane
7	AD	Andorra	[{"name": "Cyber Unit", "email": "cybercrime@policia.ad", "agency": "Policia d'Andorra"}]	\N	ncb.andorra@policia.ad	{Catalan,Spanish,French}	Europe/Andorra
8	AT	Austria	[{"name": "Cybercrime Unit", "email": "cybercrime@bmi.gv.at", "agency": "Bundesamt für Verfassungsschutz (BMI)"}]	bmi.europol@bmi.gv.at	interpol.wien@bmi.gv.at	{German,English}	Europe/Vienna
9	BE	Belgium	[{"name": "Cybercrime", "email": "fccu@police.belgium.be", "agency": "Federal Computer Crime Unit (FCCU)"}]	fccu.europol@police.belgium.be	interpol.brussels@police.belgium.be	{Dutch,French,German}	Europe/Brussels
10	BA	Bosnia and Herzegovina	[{"name": "Cybercrime Dept", "email": "cybercrime@sipa.gov.ba", "agency": "State Investigation and Protection Agency (SIPA)"}]	\N	interpol.sarajevo@sipa.gov.ba	{Bosnian,Croatian,Serbian}	Europe/Sarajevo
11	BG	Bulgaria	[{"name": "Cybercrime Unit", "email": "cybercrime@mvr.bg", "agency": "Ministry of Interior - CID"}]	mvr.europol@mvr.bg	interpol.sofia@mvr.bg	{Bulgarian,English}	Europe/Sofia
12	HR	Croatia	[{"name": "Cybercrime", "email": "cybercrime@police.hr", "agency": "Croatian Police - USKOK"}]	police.europol@police.hr	interpol.zagreb@police.hr	{Croatian,English}	Europe/Zagreb
13	CY	Cyprus	[{"name": "Cybercrime Office", "email": "cybercrime@cypruspolice.gov.cy", "agency": "Cyprus Police - CCB"}]	police.europol@cypruspolice.gov.cy	interpol.nicosia@cypruspolice.gov.cy	{Greek,Turkish,English}	Asia/Nicosia
14	CZ	Czech Republic	[{"name": "Cybercrime Dept", "email": "cybercrime@policie.cz", "agency": "Policie ČR - ÚOOZ"}]	policie.europol@policie.cz	interpol.praha@policie.cz	{Czech,English}	Europe/Prague
15	DK	Denmark	[{"name": "Cybercrime", "email": "nc3@politi.dk", "agency": "National Cyber Crime Center (NC3)"}]	politi.europol@politi.dk	interpol.koebenhavn@politi.dk	{Danish,English}	Europe/Copenhagen
16	EE	Estonia	[{"name": "Cyber", "email": "cybercrime@politsei.ee", "agency": "ESTPOL - Cybercrime Bureau"}]	politsei.europol@politsei.ee	interpol.tallinn@politsei.ee	{Estonian,English}	Europe/Tallinn
17	FI	Finland	[{"name": "Cybercrime Center", "email": "cybercrime@krp.poliisi.fi", "agency": "National Bureau of Investigation (KRP)"}]	krp.europol@krp.poliisi.fi	interpol.helsinki@krp.poliisi.fi	{Finnish,Swedish,English}	Europe/Helsinki
18	GR	Greece	[{"name": "Cyber", "email": "cybercrime@ellenicpolice.gr", "agency": "Hellenic Police - Cybercrime Unit"}]	police.europol@ellenicpolice.gr	interpol.athens@ellenicpolice.gr	{Greek,English}	Europe/Athens
19	HU	Hungary	[{"name": "Cybercrime", "email": "cybercrime@police.hu", "agency": "Hungarian Police - NNHH"}]	police.europol@police.hu	interpol.budapest@police.hu	{Hungarian,English}	Europe/Budapest
20	IS	Iceland	[{"name": "Cyber", "email": "cybercrime@logreglan.is", "agency": "Icelandic Police - NCSC"}]	\N	interpol.reykjavik@logreglan.is	{Icelandic,English}	Atlantic/Reykjavik
21	IE	Ireland	[{"name": "Cybercrime Bureau", "email": "cybercrime@garda.ie", "agency": "An Garda Síochána - GNECB"}]	garda.europol@garda.ie	interpol.dublin@garda.ie	{English,Irish}	Europe/Dublin
22	XK	Kosovo	[{"name": "Cyber", "email": "cybercrime@kosovopolice.com", "agency": "Kosovo Police - Cyber Unit"}]	\N	\N	{Albanian,Serbian,English}	Europe/Belgrade
23	LV	Latvia	[{"name": "Cyber", "email": "cybercrime@vp.gov.lv", "agency": "State Police - Cybercrime Unit"}]	vp.europol@vp.gov.lv	interpol.riga@vp.gov.lv	{Latvian,English}	Europe/Riga
24	LI	Liechtenstein	[{"name": "Cyber", "email": "cybercrime@polizei.llv.li", "agency": "Liechtenstein National Police"}]	\N	interpol.vaduz@polizei.llv.li	{German}	Europe/Vaduz
25	LT	Lithuania	[{"name": "Cyber", "email": "cybercrime@policija.lt", "agency": "Lithuanian Police - Cybercrime"}]	policija.europol@policija.lt	interpol.vilnius@policija.lt	{Lithuanian,English}	Europe/Vilnius
26	LU	Luxembourg	[{"name": "Cybercrime", "email": "cybercrime@police.lu", "agency": "Police Grand-Ducale"}]	police.europol@police.lu	interpol.luxembourg@police.lu	{Luxembourgish,French,German}	Europe/Luxembourg
27	MT	Malta	[{"name": "Cybercrime", "email": "cybercrime.pf@gov.mt", "agency": "Malta Police Force - CID"}]	police.europol@gov.mt	interpol.valletta@gov.mt	{Maltese,English}	Europe/Malta
28	MD	Moldova	[{"name": "Cyber", "email": "cybercrime@police.md", "agency": "Moldovan Police - CCCI"}]	\N	interpol.chisinau@police.md	{Romanian,Russian}	Europe/Chisinau
29	MC	Monaco	[{"name": "Cyber", "email": "cybercrime@police.monaco", "agency": "Monaco Police"}]	\N	interpol.monaco@police.monaco	{French,English}	Europe/Monaco
30	ME	Montenegro	[{"name": "Cyber", "email": "cybercrime@mup.gov.me", "agency": "Montenegro Police - Cyber Unit"}]	\N	interpol.podgorica@mup.gov.me	{Montenegrin,English}	Europe/Podgorica
31	NL	Netherlands	[{"name": "Cybercrime", "email": "cybercrime@politie.nl", "agency": "Politie - Landelijke Eenheid"}, {"name": "THTC", "email": "thtc@politie.nl", "agency": "Team High Tech Crime"}]	politie.europol@politie.nl	interpol.denhaag@politie.nl	{Dutch,English}	Europe/Amsterdam
32	MK	North Macedonia	[{"name": "Cybercrime", "email": "cybercrime@mvr.gov.mk", "agency": "Ministry of Interior - Cyber"}]	\N	interpol.skopje@mvr.gov.mk	{Macedonian,English}	Europe/Skopje
33	NO	Norway	[{"name": "Cybercrime", "email": "cybercrime@kripos.no", "agency": "Kripos - NC3"}]	kripos.europol@kripos.no	interpol.oslo@kripos.no	{Norwegian,English}	Europe/Oslo
34	PL	Poland	[{"name": "Cybercrime Bureau", "email": "cybercrime@policja.gov.pl", "agency": "Policja - CBZC"}]	policja.europol@policja.gov.pl	interpol.warszawa@policja.gov.pl	{Polish,English}	Europe/Warsaw
35	PT	Portugal	[{"name": "UC3", "email": "cybercrime@psp.pt", "agency": "PSP - Cybercrime Unit"}, {"name": "National Cybercrime Unit", "email": "unct@pj.pt", "agency": "PJ - UNCT"}]	pj.europol@pj.pt	interpol.lisboa@pj.pt	{Portuguese,English}	Europe/Lisbon
36	RO	Romania	[{"name": "Cyber", "email": "cybercrime@diicot.ro", "agency": "DIICOT - Cybercrime"}]	diicot.europol@diicot.ro	interpol.bucuresti@politieromana.ro	{Romanian,English}	Europe/Bucharest
37	SM	San Marino	[{"name": "Cyber", "email": "cybercrime@poliziastatocivile.sm", "agency": "San Marino Police"}]	\N	\N	{Italian}	Europe/San_Marino
38	RS	Serbia	[{"name": "Cyber", "email": "cybercrime@mup.gov.rs", "agency": "MUP Serbia - Cybercrime"}]	\N	interpol.beograd@mup.gov.rs	{Serbian,English}	Europe/Belgrade
39	SK	Slovakia	[{"name": "Cybercrime", "email": "cybercrime@minv.sk", "agency": "Policajný zbor - ÚBZPO"}]	minv.europol@minv.sk	interpol.bratislava@minv.sk	{Slovak,English}	Europe/Bratislava
40	SI	Slovenia	[{"name": "Cyber", "email": "cybercrime@policija.si", "agency": "Slovenian Police - Cyber"}]	policija.europol@policija.si	interpol.ljubljana@policija.si	{Slovenian,English}	Europe/Ljubljana
41	SE	Sweden	[{"name": "Cybercrime Center", "email": "cybercrime@polisen.se", "agency": "Swedish Police - NC3"}]	polisen.europol@polisen.se	interpol.stockholm@polisen.se	{Swedish,English}	Europe/Stockholm
42	CH	Switzerland	[{"name": "Cybercrime Coordination", "email": "cybercrime@fedpol.admin.ch", "agency": "Fedpol - CYCO"}]	fedpol.europol@fedpol.admin.ch	interpol.bern@fedpol.admin.ch	{German,French,Italian,English}	Europe/Zurich
43	UA	Ukraine	[{"name": "Cyber", "email": "cyberpolice@cyberpolice.gov.ua", "agency": "Cyber Police of Ukraine"}]	\N	interpol.kyiv@cyberpolice.gov.ua	{Ukrainian,English}	Europe/Kyiv
1	GB	United Kingdom	[{"name": "National Fraud Intelligence Bureau", "email": "reports@actionfraud.police.uk", "agency": "Action Fraud / City of London Police"}, {"name": "NCA Cyber Crime Unit", "email": "cybercrime@nca.gov.uk", "agency": "NCA"}]	uk.europol@nca.gov.uk	interpol.london@nca.gov.uk	{English}	Europe/London
44	VAT	Vatican City	[{"name": "Cyber", "email": "cybercrime@vatican.va", "agency": "Vatican Gendarmerie"}]	\N	\N	{Italian,Latin}	Europe/Vatican
45	US	United States	[{"name": "Internet Crime Complaint Center", "email": "ic3.gov@fbi.gov", "agency": "FBI - IC3"}, {"name": "Federal Trade Commission", "email": "reportfraud@ftc.gov", "agency": "FTC"}]	\N	interpol.washington@usdoj.gov	{English,Spanish}	America/New_York
46	CA	Canada	[{"name": "Canadian Anti-Fraud Centre", "email": "cybercrime@rcmp-grc.gc.ca", "agency": "RCMP - Cybercrime"}, {"name": "Anti-Fraud Centre", "email": "info@antifraudcentre.ca", "agency": "CAFC"}]	\N	interpol.ottawa@rcmp-grc.gc.ca	{English,French}	America/Toronto
47	MX	Mexico	[{"name": "Cybercrime", "email": "ciberpolicia@sspc.gob.mx", "agency": "Policía Federal - Ciberpolicía"}]	\N	interpol.mexico@sspc.gob.mx	{Spanish}	America/Mexico_City
48	BZ	Belize	[{"name": "Cyber", "email": "cybercrime@police.gov.bz", "agency": "Belize Police Department"}]	\N	interpol.belmopan@police.gov.bz	{English,Spanish}	America/Belize
49	CR	Costa Rica	[{"name": "Cyber", "email": "ciberdelincuencia@oij.go.cr", "agency": "OIJ - Cybercrime"}]	\N	interpol.sanjose@oij.go.cr	{Spanish,English}	America/Costa_Rica
50	CU	Cuba	[{"name": "Cyber", "email": "ciberdelito@minint.gob.cu", "agency": "PNR - Cybercrime"}]	\N	interpol.la_habana@minint.gob.cu	{Spanish}	America/Havana
51	DO	Dominican Republic	[{"name": "Cybercrime", "email": "ciberdelito@policianacional.gov.do", "agency": "DNCD - Cyber"}]	\N	interpol.santo_domingo@policianacional.gov.do	{Spanish}	America/Santo_Domingo
52	SV	El Salvador	[{"name": "Cyber", "email": "ciberdelincuencia@pnc.gob.sv", "agency": "PNC - Cybercrime"}]	\N	interpol.san_salvador@pnc.gob.sv	{Spanish}	America/El_Salvador
53	GT	Guatemala	[{"name": "Cyber", "email": "ciberdelincuencia@pnc.gob.gt", "agency": "PNC Guatemala - Cyber"}]	\N	interpol.guatemala@pnc.gob.gt	{Spanish}	America/Guatemala
54	HT	Haiti	[{"name": "Cyber", "email": "cybercrime@pnh.gov.ht", "agency": "PNH - Cyber"}]	\N	interbol.port_au_prince@pnh.gov.ht	{French,"Haitian Creole"}	America/Port-au-Prince
55	HN	Honduras	[{"name": "Cyber", "email": "ciberdelincuencia@policianacional.gob.hn", "agency": "Policía Nacional - Cyber"}]	\N	interpol.tegucigalpa@policianacional.gob.hn	{Spanish}	America/Tegucigalpa
56	JM	Jamaica	[{"name": "Cyber", "email": "cybercrime@jcf.gov.jm", "agency": "JCF - Cybercrime"}]	\N	interpol.kingston@jcf.gov.jm	{English}	America/Jamaica
57	NI	Nicaragua	[{"name": "Cyber", "email": "ciberdelincuencia@policia.gob.ni", "agency": "Policía Nacional - Cyber"}]	\N	interpol.managua@policia.gob.ni	{Spanish}	America/Managua
58	PA	Panama	[{"name": "Cyber", "email": "ciberdelincuencia@policia.gob.pa", "agency": "Policía Nacional - Cyber"}]	\N	interbol.panama@policia.gob.pa	{Spanish,English}	America/Panama
59	TT	Trinidad and Tobago	[{"name": "Cyber", "email": "cybercrime@ttps.gov.tt", "agency": "TTPS - Cybercrime"}]	\N	interpol.port_of_spain@ttps.gov.tt	{English}	America/Port_of_Spain
60	BS	Bahamas	[{"name": "Cyber", "email": "cybercrime@rbpf.bs", "agency": "Royal Bahamas Police"}]	\N	interpol.nassau@rbpf.bs	{English}	America/Nassau
61	BB	Barbados	[{"name": "Cyber", "email": "cybercrime@barbadospolice.gov.bb", "agency": "RBPF Barbados"}]	\N	interpol.bridgetown@barbadospolice.gov.bb	{English}	America/Barbados
62	AR	Argentina	[{"name": "Cybercrime", "email": "ciberdelincuencia@pfa.gov.ar", "agency": "Policía Federal Argentina - Cyber"}]	\N	interpol.buenos_aires@pfa.gov.ar	{Spanish}	America/Argentina/Buenos_Aires
63	BO	Bolivia	[{"name": "Cyber", "email": "ciberdelincuencia@policia.gob.bo", "agency": "Policía Boliviana - Cyber"}]	\N	interpol.la_paz@policia.gob.bo	{Spanish,Quechua,Aymara}	America/La_Paz
64	BR	Brazil	[{"name": "Cybercrime", "email": "cibercrime@pf.gov.br", "agency": "Polícia Federal - Cyber"}]	\N	interpol.brasilia@pf.gov.br	{Portuguese,Spanish}	America/Sao_Paulo
65	CL	Chile	[{"name": "Cyber", "email": "cibercrimen@pdi.gov.cl", "agency": "PDI - Brigada del Cibercrimen"}]	\N	interpol.santiago@pdi.gov.cl	{Spanish}	America/Santiago
66	CO	Colombia	[{"name": "Cyber", "email": "ciberpolicia@policia.gov.co", "agency": "Policía Nacional - Ciberpolicía"}]	\N	interpol.bogota@policia.gov.co	{Spanish}	America/Bogota
67	EC	Ecuador	[{"name": "Cyber", "email": "ciberdelincuencia@policia.gob.ec", "agency": "Policía Nacional - Cyber"}]	\N	interpol.quito@policia.gob.ec	{Spanish,Quechua}	America/Guayaquil
68	GY	Guyana	[{"name": "Cyber", "email": "cybercrime@gpf.gov.gy", "agency": "Guyana Police Force"}]	\N	interpol.georgetown@gpf.gov.gy	{English}	America/Guyana
69	PY	Paraguay	[{"name": "Cyber", "email": "ciberdelincuencia@policia.gov.py", "agency": "Policía Nacional - Cyber"}]	\N	interpol.asuncion@policia.gov.py	{Spanish,Guarani}	America/Asuncion
70	PE	Peru	[{"name": "Cybercrime", "email": "ciberdelincuencia@pnp.gob.pe", "agency": "PNP - Divicri"}]	\N	interpol.lima@pnp.gob.pe	{Spanish,Quechua,Aymara}	America/Lima
71	SR	Suriname	[{"name": "Cyber", "email": "cybercrime@korpspolitie.sr", "agency": "Suriname Police - Cyber"}]	\N	interpol.paramaribo@korpspolitie.sr	{Dutch,English}	America/Paramaribo
72	UY	Uruguay	[{"name": "Cyber", "email": "ciberdelincuencia@policia.gub.uy", "agency": "Policía Nacional - Cyber"}]	\N	interpol.montevideo@policia.gub.uy	{Spanish}	America/Montevideo
73	VE	Venezuela	[{"name": "Cyber", "email": "ciberdelincuencia@cicpc.gob.ve", "agency": "CICPC - Cyber"}]	\N	interpol.caracas@cicpc.gob.ve	{Spanish}	America/Caracas
74	AF	Afghanistan	[{"name": "Cyber", "email": "cybercrime@moi.gov.af", "agency": "Afghan Police - Cyber"}]	\N	interpol.kabul@moi.gov.af	{Pashto,Dari}	Asia/Kabul
75	AM	Armenia	[{"name": "Cyber", "email": "cybercrime@police.am", "agency": "Armenian Police - Cyber"}]	\N	interpol.yerevan@police.am	{Armenian,Russian}	Asia/Yerevan
76	AZ	Azerbaijan	[{"name": "Cyber", "email": "cybercrime@mia.gov.az", "agency": "MIA Azerbaijan - Cyber"}]	\N	interpol.baku@mia.gov.az	{Azerbaijani,English}	Asia/Baku
77	BH	Bahrain	[{"name": "Cyber", "email": "cybercrime@moi.gov.bh", "agency": "Bahrain Police - Cyber"}]	\N	interpol.manama@moi.gov.bh	{Arabic,English}	Asia/Bahrain
78	BD	Bangladesh	[{"name": "Cybercrime", "email": "cybercrime@police.gov.bd", "agency": "Bangladesh Police - Cyber"}]	\N	interpol.dhaka@police.gov.bd	{Bengali,English}	Asia/Dhaka
79	BT	Bhutan	[{"name": "Cyber", "email": "cybercrime@rbp.gov.bt", "agency": "RBP Bhutan - Cyber"}]	\N	interpol.thimphu@rbp.gov.bt	{Dzongkha,English}	Asia/Thimphu
80	BN	Brunei	[{"name": "Cyber", "email": "cybercrime@rbpf.gov.bn", "agency": "RBPF Brunei - Cyber"}]	\N	interpol.bandar_seri_begawan@rbpf.gov.bn	{Malay,English}	Asia/Brunei
81	KH	Cambodia	[{"name": "Cyber", "email": "cybercrime@nationalepolice.gov.kh", "agency": "National Police - Cyber"}]	\N	interpol.phnom_penh@nationalepolice.gov.kh	{Khmer,English}	Asia/Phnom_Penh
82	CN	China	[{"name": "Cyber", "email": "cybercrime@mps.gov.cn", "agency": "MPS - Cybercrime"}]	\N	interpol.beijing@mps.gov.cn	{Chinese}	Asia/Shanghai
83	GE	Georgia	[{"name": "Cyber", "email": "cybercrime@police.ge", "agency": "MIA Georgia - Cyber"}]	\N	interpol.tbilisi@police.ge	{Georgian,English}	Asia/Tbilisi
84	IN	India	[{"name": "Cyber Crime Coordination Centre", "email": "cybercrime@ncrb.gov.in", "agency": "NCRB - Cybercrime"}, {"name": "Indian Cybercrime Coordination Centre", "email": "info@cybercrime.gov.in", "agency": "I4C"}]	\N	interpol.new_delhi@ncb.gov.in	{Hindi,English}	Asia/Kolkata
85	ID	Indonesia	[{"name": "Cyber", "email": "cybercrime@polri.go.id", "agency": "POLRI - Cybercrime"}]	\N	interpol.jakarta@polri.go.id	{Indonesian,English}	Asia/Jakarta
86	IR	Iran	[{"name": "Cyber", "email": "cybercrime@police.ir", "agency": "NAJA Iran - Cyber"}]	\N	interpol.tehran@police.ir	{Persian}	Asia/Tehran
87	IQ	Iraq	[{"name": "Cyber", "email": "cybercrime@moi.gov.iq", "agency": "Iraqi Police - Cyber"}]	\N	interpol.baghdad@moi.gov.iq	{Arabic,Kurdish}	Asia/Baghdad
88	IL	Israel	[{"name": "Cybercrime", "email": "cybercrime@police.gov.il", "agency": "Israel Police - Lahav 433"}]	\N	interpol.jerusalem@police.gov.il	{Hebrew,English,Arabic}	Asia/Jerusalem
89	JP	Japan	[{"name": "Cybercrime", "email": "cybercrime@npa.go.jp", "agency": "NPA Japan - Cyber"}]	\N	interpol.tokyo@npa.go.jp	{Japanese,English}	Asia/Tokyo
90	JO	Jordan	[{"name": "Cyber", "email": "cybercrime@psd.gov.jo", "agency": "PSD Jordan - Cyber"}]	\N	interpol.amman@psd.gov.jo	{Arabic,English}	Asia/Amman
91	KZ	Kazakhstan	[{"name": "Cyber", "email": "cybercrime@kdmp.gov.kz", "agency": "MIA Kazakhstan - Cyber"}]	\N	interpol.astana@kdmp.gov.kz	{Kazakh,Russian}	Asia/Almaty
92	KP	North Korea	[{"name": "Cyber", "email": "cybercrime@kp.gov.kp", "agency": "Korean Police - Cyber"}]	\N	\N	{Korean}	Asia/Pyongyang
93	KR	South Korea	[{"name": "Cybercrime", "email": "cybercrime@police.go.kr", "agency": "KNPA - Cyber Bureau"}]	\N	interpol.seoul@police.go.kr	{Korean,English}	Asia/Seoul
94	KW	Kuwait	[{"name": "Cyber", "email": "cybercrime@moi.gov.kw", "agency": "MOI Kuwait - Cyber"}]	\N	interpol.kuwait@moi.gov.kw	{Arabic,English}	Asia/Kuwait
95	KG	Kyrgyzstan	[{"name": "Cyber", "email": "cybercrime@mvd.gov.kg", "agency": "MIA Kyrgyzstan - Cyber"}]	\N	interpol.bishkek@mvd.gov.kg	{Kyrgyz,Russian}	Asia/Bishkek
96	LA	Laos	[{"name": "Cyber", "email": "cybercrime@mps.gov.la", "agency": "Lao Police - Cyber"}]	\N	interpol.vientiane@mps.gov.la	{Lao,French}	Asia/Vientiane
97	LB	Lebanon	[{"name": "Cyber", "email": "cybercrime@isf.gov.lb", "agency": "ISF Lebanon - Cyber"}]	\N	interpol.beirut@isf.gov.lb	{Arabic,French,English}	Asia/Beirut
98	MY	Malaysia	[{"name": "Cybercrime", "email": "cybercrime@pdrm.gov.my", "agency": "PDRM - Commercial Crime"}, {"name": "Malaysian CERT", "email": "mycert@mycert.org.my", "agency": "MyCERT"}]	\N	interpol.kuala_lumpur@pdrm.gov.my	{Malay,English,Chinese}	Asia/Kuala_Lumpur
99	MV	Maldives	[{"name": "Cyber", "email": "cybercrime@mps.gov.mv", "agency": "MPS Maldives - Cyber"}]	\N	interpol.male@mps.gov.mv	{Dhivehi,English}	Indian/Maldives
100	MN	Mongolia	[{"name": "Cyber", "email": "cybercrime@police.mn", "agency": "Mongolian Police - Cyber"}]	\N	interpol.ulaanbaatar@police.mn	{Mongolian}	Asia/Ulaanbaatar
101	MM	Myanmar	[{"name": "Cyber", "email": "cybercrime@myanmarspecialbranch.gov.mm", "agency": "Myanmar Police - Cyber"}]	\N	interpol.yangon@myanmarspecialbranch.gov.mm	{Burmese,English}	Asia/Yangon
102	NP	Nepal	[{"name": "Cyber", "email": "cybercrime@nepalpolice.gov.np", "agency": "Nepal Police - Cyber"}]	\N	interpol.kathmandu@nepalpolice.gov.np	{Nepali,English}	Asia/Kathmandu
103	OM	Oman	[{"name": "Cyber", "email": "cybercrime@rop.gov.om", "agency": "ROP Oman - Cyber"}]	\N	interpol.muscat@rop.gov.om	{Arabic,English}	Asia/Muscat
104	PK	Pakistan	[{"name": "NR3C", "email": "cybercrime@fia.gov.pk", "agency": "FIA - Cybercrime"}]	\N	interpol.islamabad@fia.gov.pk	{Urdu,English}	Asia/Karachi
105	PH	Philippines	[{"name": "Anti-Cybercrime Group", "email": "acgc@pnp.gov.ph", "agency": "PNP - ACGC"}, {"name": "NBI Cyber", "email": "cybercrime@nbi.gov.ph", "agency": "NBI - Cybercrime"}]	\N	interpol.manila@pnp.gov.ph	{Filipino,English}	Asia/Manila
106	QA	Qatar	[{"name": "Cyber", "email": "cybercrime@moi.gov.qa", "agency": "MOI Qatar - Cyber"}]	\N	interpol.doha@moi.gov.qa	{Arabic,English}	Asia/Qatar
107	SA	Saudi Arabia	[{"name": "Cyber", "email": "cybercrime@moi.gov.sa", "agency": "Saudi Police - Cyber"}]	\N	interpol.riyadh@moi.gov.sa	{Arabic,English}	Asia/Riyadh
108	SG	Singapore	[{"name": "Commercial Affairs Dept", "email": "cybercrime@spf.gov.sg", "agency": "Singapore Police - CAD"}, {"name": "Cyber Security Agency", "email": "report@csa.gov.sg", "agency": "CSA Singapore"}]	\N	interpol.singapore@spf.gov.sg	{English,Malay,Chinese,Tamil}	Asia/Singapore
109	LK	Sri Lanka	[{"name": "Cyber", "email": "cybercrime@police.lk", "agency": "Sri Lanka Police - Cyber"}]	\N	interpol.colombo@police.lk	{Sinhala,Tamil,English}	Asia/Colombo
110	SY	Syria	[{"name": "Cyber", "email": "cybercrime@moi.gov.sy", "agency": "Syrian Police - Cyber"}]	\N	interpol.damascus@moi.gov.sy	{Arabic}	Asia/Damascus
111	TW	Taiwan	[{"name": "Cyber", "email": "cybercrime@cid.police.gov.tw", "agency": "CIB Taiwan - Cyber"}]	\N	\N	{Chinese,English}	Asia/Taipei
112	TJ	Tajikistan	[{"name": "Cyber", "email": "cybercrime@mvd.tj", "agency": "Tajik Police - Cyber"}]	\N	interpol.dushanbe@mvd.tj	{Tajik,Russian}	Asia/Dushanbe
113	TH	Thailand	[{"name": "Cybercrime", "email": "cybercrime@royalthaipolice.go.th", "agency": "Thai Police - Cyber"}]	\N	interpol.bangkok@royalthaipolice.go.th	{Thai,English}	Asia/Bangkok
114	TL	Timor-Leste	[{"name": "Cyber", "email": "cybercrime@pntl.gov.tl", "agency": "PNTL - Cyber"}]	\N	interpol.dili@pntl.gov.tl	{Tetum,Portuguese}	Asia/Dili
115	TR	Turkey	[{"name": "Cyber", "email": "cybercrime@egm.gov.tr", "agency": "Turkish Police - Cybercrime"}]	\N	interpol.ankara@egm.gov.tr	{Turkish,English}	Europe/Istanbul
116	TM	Turkmenistan	[{"name": "Cyber", "email": "cybercrime@mvd.gov.tm", "agency": "Turkmen Police - Cyber"}]	\N	interpol.ashgabat@mvd.gov.tm	{Turkmen,Russian}	Asia/Ashgabat
117	AE	United Arab Emirates	[{"name": "Cyber", "email": "cybercrime@moi.gov.ae", "agency": "UAE Police - Cybercrime"}]	\N	interpol.abu_dhabi@moi.gov.ae	{Arabic,English}	Asia/Dubai
118	UZ	Uzbekistan	[{"name": "Cyber", "email": "cybercrime@mia.uz", "agency": "Uzbek Police - Cyber"}]	\N	interpol.tashkent@mia.uz	{Uzbek,Russian}	Asia/Tashkent
119	VN	Vietnam	[{"name": "Cyber", "email": "cybercrime@mps.gov.vn", "agency": "Vietnam Police - Cyber"}]	\N	interpol.hanoi@mps.gov.vn	{Vietnamese,English}	Asia/Ho_Chi_Minh
120	YE	Yemen	[{"name": "Cyber", "email": "cybercrime@moi.gov.ye", "agency": "Yemen Police - Cyber"}]	\N	interpol.sanaa@moi.gov.ye	{Arabic}	Asia/Aden
121	DZ	Algeria	[{"name": "Cyber", "email": "cybercrime@gsp.mps.dz", "agency": "DGSN Algeria - Cyber"}]	\N	interpol.alger@gsp.mps.dz	{Arabic,French}	Africa/Algiers
122	AO	Angola	[{"name": "Cyber", "email": "cybercrime@minint.gov.ao", "agency": "Angola Police - Cyber"}]	\N	interpol.luanda@minint.gov.ao	{Portuguese}	Africa/Luanda
123	BJ	Benin	[{"name": "Cyber", "email": "cybercrime@police.gov.bj", "agency": "Benin Police - Cyber"}]	\N	interpol.cotonou@police.gov.bj	{French}	Africa/Porto-Novo
124	BW	Botswana	[{"name": "Cyber", "email": "cybercrime@bps.gov.bw", "agency": "BPS Botswana - Cyber"}]	\N	interpol.gaborone@bps.gov.bw	{English,Setswana}	Africa/Gaborone
125	BF	Burkina Faso	[{"name": "Cyber", "email": "cybercrime@police.gov.bf", "agency": "Burkina Police - Cyber"}]	\N	interpol.ouagadougou@police.gov.bf	{French}	Africa/Ouagadougou
126	BI	Burundi	[{"name": "Cyber", "email": "cybercrime@police.gov.bi", "agency": "Burundi Police - Cyber"}]	\N	interpol.bujumbura@police.gov.bi	{Kirundi,French}	Africa/Bujumbura
127	CM	Cameroon	[{"name": "Cyber", "email": "cybercrime@police.gov.cm", "agency": "Cameroon Police - Cyber"}]	\N	interpol.yaounde@police.gov.cm	{French,English}	Africa/Douala
128	CV	Cape Verde	[{"name": "Cyber", "email": "cybercrime@police.cv", "agency": "Cape Verde Police - Cyber"}]	\N	interpol.praia@police.cv	{Portuguese}	Atlantic/Cape_Verde
129	CF	Central African Republic	[{"name": "Cyber", "email": "cybercrime@police.gov.cf", "agency": "CAR Police - Cyber"}]	\N	interpol.bangui@police.gov.cf	{French,Sango}	Africa/Bangui
130	TD	Chad	[{"name": "Cyber", "email": "cybercrime@police.gov.td", "agency": "Chad Police - Cyber"}]	\N	interpol.ndjamena@police.gov.td	{French,Arabic}	Africa/Ndjamena
131	KM	Comoros	[{"name": "Cyber", "email": "cybercrime@police.km", "agency": "Comoros Police - Cyber"}]	\N	interpol.moroni@police.km	{Comorian,French,Arabic}	Indian/Comoro
132	CG	Republic of Congo	[{"name": "Cyber", "email": "cybercrime@police.cg", "agency": "Congo Police - Cyber"}]	\N	interpol.brazzaville@police.cg	{French}	Africa/Brazzaville
133	CD	DR Congo	[{"name": "Cyber", "email": "cybercrime@police.gov.cd", "agency": "DRC Police - Cyber"}]	\N	interpol.kinshasa@police.gov.cd	{French}	Africa/Kinshasa
134	CI	Côte d'Ivoire	[{"name": "Cyber", "email": "cybercrime@police.ci", "agency": "Ivorian Police - Cyber"}]	\N	interpol.abidjan@police.ci	{French}	Africa/Abidjan
135	DJ	Djibouti	[{"name": "Cyber", "email": "cybercrime@police.dj", "agency": "Djibouti Police - Cyber"}]	\N	interpol.djibouti@police.dj	{French,Arabic}	Africa/Djibouti
136	EG	Egypt	[{"name": "Cybercrime", "email": "cybercrime@moi.gov.eg", "agency": "Egyptian Police - NCB"}]	\N	interpol.cairo@moi.gov.eg	{Arabic,English}	Africa/Cairo
137	GQ	Equatorial Guinea	[{"name": "Cyber", "email": "cybercrime@police.gq", "agency": "EG Police - Cyber"}]	\N	interpol.malabo@police.gq	{Spanish,French,Portuguese}	Africa/Malabo
138	ER	Eritrea	[{"name": "Cyber", "email": "cybercrime@police.gov.er", "agency": "Eritrea Police - Cyber"}]	\N	interpol.asmara@police.gov.er	{Tigrinya,Arabic,English}	Africa/Asmara
139	SZ	Eswatini	[{"name": "Cyber", "email": "cybercrime@police.org.sz", "agency": "RSP Eswatini - Cyber"}]	\N	interpol.mbabane@police.org.sz	{Swazi,English}	Africa/Mbabane
140	ET	Ethiopia	[{"name": "Cyber", "email": "cybercrime@ethiopolice.gov.et", "agency": "Ethiopian Police - Cyber"}]	\N	interpol.addis_ababa@ethiopolice.gov.et	{Amharic,English}	Africa/Addis_Ababa
141	GA	Gabon	[{"name": "Cyber", "email": "cybercrime@police.ga", "agency": "Gabon Police - Cyber"}]	\N	interpol.libreville@police.ga	{French}	Africa/Libreville
142	GM	Gambia	[{"name": "Cyber", "email": "cybercrime@police.gm", "agency": "Gambia Police - Cyber"}]	\N	interpol.banjul@police.gm	{English}	Africa/Banjul
143	GH	Ghana	[{"name": "Cyber", "email": "cybercrime@ghanapolice.gov.gh", "agency": "Ghana Police - Cybercrime Unit"}]	\N	interpol.accra@ghanapolice.gov.gh	{English}	Africa/Accra
144	GN	Guinea	[{"name": "Cyber", "email": "cybercrime@police.gov.gn", "agency": "Guinea Police - Cyber"}]	\N	interpol.conakry@police.gov.gn	{French}	Africa/Conakry
145	GW	Guinea-Bissau	[{"name": "Cyber", "email": "cybercrime@policia.gov.gw", "agency": "GB Police - Cyber"}]	\N	interpol.bissau@policia.gov.gw	{Portuguese}	Africa/Bissau
146	KE	Kenya	[{"name": "Cyber", "email": "cybercrime@cid.go.ke", "agency": "DCI Kenya - Cybercrime"}]	\N	interpol.nairobi@cid.go.ke	{Swahili,English}	Africa/Nairobi
147	LS	Lesotho	[{"name": "Cyber", "email": "cybercrime@police.gov.ls", "agency": "LMPS Lesotho - Cyber"}]	\N	interpol.maseru@police.gov.ls	{Sesotho,English}	Africa/Maseru
148	LR	Liberia	[{"name": "Cyber", "email": "cybercrime@lnp.gov.lr", "agency": "Liberia Police - Cyber"}]	\N	interpol.monrovia@lnp.gov.lr	{English}	Africa/Monrovia
149	LY	Libya	[{"name": "Cyber", "email": "cybercrime@moi.gov.ly", "agency": "Libya Police - Cyber"}]	\N	interpol.tripoli@moi.gov.ly	{Arabic}	Africa/Tripoli
150	MG	Madagascar	[{"name": "Cyber", "email": "cybercrime@police.mg", "agency": "Madagascar Police - Cyber"}]	\N	interpol.antananarivo@police.mg	{Malagasy,French}	Indian/Antananarivo
151	MW	Malawi	[{"name": "Cyber", "email": "cybercrime@police.gov.mw", "agency": "Malawi Police - Cyber"}]	\N	interpol.lilongwe@police.gov.mw	{English,Chichewa}	Africa/Blantyre
152	ML	Mali	[{"name": "Cyber", "email": "cybercrime@police.ml", "agency": "Mali Police - Cyber"}]	\N	interpol.bamako@police.ml	{French,Bambara}	Africa/Bamako
153	MR	Mauritania	[{"name": "Cyber", "email": "cybercrime@police.mr", "agency": "Mauritania Police - Cyber"}]	\N	interpol.nouakchott@police.mr	{Arabic,French}	Africa/Nouakchott
154	MU	Mauritius	[{"name": "Cyber", "email": "cybercrime@police.mu", "agency": "Mauritius Police - Cyber"}]	\N	interpol.port_louis@police.mu	{English,French,"Mauritian Creole"}	Indian/Mauritius
155	MA	Morocco	[{"name": "Cybercrime", "email": "cybercrime@dgspn.gov.ma", "agency": "DGSN Morocco - Cyber"}]	\N	interpol.rabat@dgspn.gov.ma	{Arabic,French}	Africa/Casablanca
156	MZ	Mozambique	[{"name": "Cyber", "email": "cybercrime@policia.gov.mz", "agency": "Mozambique Police - Cyber"}]	\N	interpol.maputo@policia.gov.mz	{Portuguese}	Africa/Maputo
157	NA	Namibia	[{"name": "Cyber", "email": "cybercrime@namfis.nampol.gov.na", "agency": "Namibian Police - Cyber"}]	\N	interpol.windhoek@nampol.gov.na	{English}	Africa/Windhoek
158	NE	Niger	[{"name": "Cyber", "email": "cybercrime@police.ne", "agency": "Niger Police - Cyber"}]	\N	interpol.niamey@police.ne	{French}	Africa/Niamey
159	NG	Nigeria	[{"name": "Cyber", "email": "cybercrime@npf.gov.ng", "agency": "NPF - Cybercrime Unit"}, {"name": "Economic & Financial Crimes Commission", "email": "info@efcc.gov.ng", "agency": "EFCC"}]	\N	interpol.abuja@npf.gov.ng	{English}	Africa/Lagos
160	RW	Rwanda	[{"name": "Cyber", "email": "cybercrime@police.gov.rw", "agency": "RNP Rwanda - Cyber"}]	\N	interpol.kigali@police.gov.rw	{Kinyarwanda,French,English}	Africa/Kigali
161	ST	São Tomé and Príncipe	[{"name": "Cyber", "email": "cybercrime@police.st", "agency": "STP Police - Cyber"}]	\N	\N	{Portuguese}	Africa/Sao_Tome
162	SN	Senegal	[{"name": "Cyber", "email": "cybercrime@police.sn", "agency": "Senegal Police - Cyber"}]	\N	interpol.dakar@police.sn	{French}	Africa/Dakar
163	SC	Seychelles	[{"name": "Cyber", "email": "cybercrime@spf.gov.sc", "agency": "Seychelles Police - Cyber"}]	\N	interpol.victoria@spf.gov.sc	{"Seychellois Creole",English,French}	Indian/Mahe
164	SL	Sierra Leone	[{"name": "Cyber", "email": "cybercrime@slpolice.gov.sl", "agency": "Sierra Leone Police - Cyber"}]	\N	interpol.freetown@slpolice.gov.sl	{English}	Africa/Freetown
165	SO	Somalia	[{"name": "Cyber", "email": "cybercrime@spf.gov.so", "agency": "Somali Police - Cyber"}]	\N	interpol.mogadishu@spf.gov.so	{Somali,Arabic}	Africa/Mogadishu
166	ZA	South Africa	[{"name": "Commercial Crime", "email": "cybercrime@saps.gov.za", "agency": "SAPS - Cybercrime"}]	\N	interpol.pretoria@saps.gov.za	{English,Afrikaans,Zulu}	Africa/Johannesburg
167	SS	South Sudan	[{"name": "Cyber", "email": "cybercrime@nps.gov.ss", "agency": "SSNPS - Cyber"}]	\N	interpol.juba@nps.gov.ss	{English}	Africa/Juba
168	SD	Sudan	[{"name": "Cyber", "email": "cybercrime@moi.gov.sd", "agency": "Sudan Police - Cyber"}]	\N	interpol.khartoum@moi.gov.sd	{Arabic,English}	Africa/Khartoum
169	TZ	Tanzania	[{"name": "Cyber", "email": "cybercrime@tanzaniapolice.go.tz", "agency": "Tanzania Police - Cyber"}]	\N	interpol.dar_es_salaam@tanzaniapolice.go.tz	{Swahili,English}	Africa/Dar_es_Salaam
170	TG	Togo	[{"name": "Cyber", "email": "cybercrime@police.tg", "agency": "Togo Police - Cyber"}]	\N	interpol.lome@police.tg	{French}	Africa/Lome
171	TN	Tunisia	[{"name": "Cyber", "email": "cybercrime@interieur.gov.tn", "agency": "Tunisian Police - Cyber"}]	\N	interpol.tunis@interieur.gov.tn	{Arabic,French}	Africa/Tunis
172	UG	Uganda	[{"name": "Cyber", "email": "cybercrime@upf.go.ug", "agency": "UPF Uganda - Cyber"}]	\N	interpol.kampala@upf.go.ug	{English,Swahili}	Africa/Kampala
173	EH	Western Sahara	[{"name": "Cyber", "email": "cybercrime@police.eh", "agency": "Regional Police"}]	\N	\N	{Arabic,Spanish}	Africa/El_Aaiun
174	ZM	Zambia	[{"name": "Cyber", "email": "cybercrime@zambiapolice.gov.zm", "agency": "Zambia Police - Cyber"}]	\N	interpol.lusaka@zambiapolice.gov.zm	{English}	Africa/Lusaka
175	ZW	Zimbabwe	[{"name": "Cyber", "email": "cybercrime@zrp.gov.zw", "agency": "ZRP Zimbabwe - Cyber"}]	\N	interpol.harare@zrp.gov.zw	{English,Shona,Ndebele}	Africa/Harare
176	AU	Australia	[{"name": "Australian Federal Police", "email": "cybercrime@afp.gov.au", "agency": "AFP - Cybercrime"}, {"name": "Australian Cyber Security Centre", "email": "report@cyber.gov.au", "agency": "ACSC"}]	\N	interpol.canberra@afp.gov.au	{English}	Australia/Sydney
177	FJ	Fiji	[{"name": "Cyber", "email": "cybercrime@fijipolice.gov.fj", "agency": "Fiji Police - Cyber"}]	\N	interpol.suva@fijipolice.gov.fj	{English,Fijian,Hindi}	Pacific/Fiji
178	KI	Kiribati	[{"name": "Cyber", "email": "cybercrime@kpf.gov.ki", "agency": "Kiribati Police"}]	\N	\N	{English,Gilbertese}	Pacific/Tarawa
179	MH	Marshall Islands	[{"name": "Cyber", "email": "cybercrime@rmiopd.org", "agency": "RMI Police"}]	\N	\N	{English,Marshallese}	Pacific/Majuro
180	FM	Micronesia	[{"name": "Cyber", "email": "cybercrime@fsmpublicsafety.gov.fm", "agency": "FSM Police"}]	\N	\N	{English}	Pacific/Pohnpei
181	NR	Nauru	[{"name": "Cyber", "email": "cybercrime@nauru.gov.nr", "agency": "Nauru Police"}]	\N	\N	{Nauruan,English}	Pacific/Nauru
182	NZ	New Zealand	[{"name": "Cybercrime", "email": "cybercrime@police.govt.nz", "agency": "NZ Police - Online Crime"}, {"name": "CERT", "email": "info@cert.govt.nz", "agency": "CERT NZ"}]	\N	interpol.wellington@police.govt.nz	{English,Maori}	Pacific/Auckland
183	PW	Palau	[{"name": "Cyber", "email": "cybercrime@palaupd.org", "agency": "Palau Police"}]	\N	\N	{English,Palauan}	Pacific/Palau
184	PG	Papua New Guinea	[{"name": "Cyber", "email": "cybercrime@police.gov.pg", "agency": "RPNGC - Cyber"}]	\N	interpol.port_moresby@police.gov.pg	{English,"Tok Pisin"}	Pacific/Port_Moresby
185	WS	Samoa	[{"name": "Cyber", "email": "cybercrime@police.gov.ws", "agency": "Samoa Police - Cyber"}]	\N	interpol.apia@police.gov.ws	{Samoan,English}	Pacific/Apia
186	SB	Solomon Islands	[{"name": "Cyber", "email": "cybercrime@rsipf.gov.sb", "agency": "RSIPF - Cyber"}]	\N	\N	{English}	Pacific/Guadalcanal
187	TO	Tonga	[{"name": "Cyber", "email": "cybercrime@police.gov.to", "agency": "Tonga Police - Cyber"}]	\N	\N	{Tongan,English}	Pacific/Tongatapu
188	TV	Tuvalu	[{"name": "Cyber", "email": "cybercrime@tuvalupolice.tv", "agency": "Tuvalu Police"}]	\N	\N	{Tuvaluan,English}	Pacific/Funafuti
189	VU	Vanuatu	[{"name": "Cyber", "email": "cybercrime@police.gov.vu", "agency": "Vanuatu Police - Cyber"}]	\N	\N	{Bislama,English,French}	Pacific/Efate
\.


--
-- Data for Name: evidence; Type: TABLE DATA; Schema: public; Owner: gfin
--

COPY public.evidence (id, case_id, evidence_id, phase, finding, source_provider, source_url, source_type, confidence, content_hash, "timestamp", created_date) FROM stdin;
1	GFIN-CASE-001	E-001	CAMPAIGN_DISCOVERY	50+ domains impersonating CNC Intelligence	CNC Intelligence Inc.	https://cncintel.com/report	Public corporate report	HIGH	\N	2026-08-26 19:31:43.997238+00	2026-08-26 19:31:43.997238+00
2	GFIN-CASE-001	E-004	DOMAIN_REGISTRATION	cncintelinfo.com registered 2026-02-26 via NameCheap, ProtonMail MX only	Google DoH	dns.google	DNS protocol query	HIGH	\N	2026-08-26 19:31:43.998197+00	2026-08-26 19:31:43.998197+00
3	GFIN-CASE-001	E-007	IP_INTELLIGENCE	IP 91.195.240.123 = AS47846 SEDO GmbH, Munich	ipinfo.io	ipinfo.io	IP geolocation	HIGH	\N	2026-08-26 19:31:43.998583+00	2026-08-26 19:31:43.998583+00
4	GFIN-CASE-001	E-011	VICTIM_CORRELATION	Reddit victims report losing $35,000 to fake CNC Intelligence representatives	Reddit	reddit.com/r/Scams	Public forum posts	MEDIUM	\N	2026-08-26 19:31:43.99894+00	2026-08-26 19:31:43.99894+00
5	GFIN-CASE-001	E-016	LAW_ENFORCEMENT	FBI San Diego seized MyChargeBack, Payback LTD, Claim Justice as connected recovery scam network	FBI	fbi.gov	Law enforcement press release	HIGH	\N	2026-08-26 19:31:43.999359+00	2026-08-26 19:31:43.999359+00
\.


--
-- Data for Name: people; Type: TABLE DATA; Schema: public; Owner: gfin
--

COPY public.people (id, case_id, role, name, entity_type, details, is_verified, source, confidence, created_date) FROM stdin;
1	GFIN-CASE-001	VICTIM	CNC Intelligence Inc.	ORGANIZATION	Legitimate crypto investigation firm being impersonated.	f	CNC Intelligence report	CONFIRMED	2026-08-26 19:31:43.992589+00
2	GFIN-CASE-001	SUSPECT	Scammer(s) — Real Name Unknown	UNKNOWN	Domain privacy protection active. Requires legal process.	f	RDAP/WHOIS	UNRESOLVED	2026-08-26 19:31:43.993262+00
3	GFIN-CASE-001	SUSPECT	Payback LTD	ORGANIZATION	Recovery scam — website SEIZED by FBI San Diego.	f	Reddit + FBI press release	STRONGLY_SUPPORTED	2026-08-26 19:31:43.993668+00
4	GFIN-CASE-001	SUSPECT	MyChargeBack	ORGANIZATION	Recovery scam — website SEIZED by FBI.	f	FBI press release	STRONGLY_SUPPORTED	2026-08-26 19:31:43.994131+00
5	GFIN-CASE-001	SUSPECT	Claim Justice	ORGANIZATION	Recovery scam — website SEIZED by FBI.	f	FBI press release	STRONGLY_SUPPORTED	2026-08-26 19:31:43.994494+00
6	GFIN-CASE-001	SUSPECT	Cyber-Forensics.net	ORGANIZATION	Recovery scam listed on CryptoLegal UK.	f	CryptoLegal UK + LegalByte	STRONGLY_SUPPORTED	2026-08-26 19:31:43.994855+00
7	GFIN-CASE-001	WITNESS	FBI San Diego Field Office	ORGANIZATION	Seized Payback LTD, MyChargeBack, Claim Justice websites.	f	FBI press release	CONFIRMED	2026-08-26 19:31:43.995215+00
8	GFIN-CASE-001	VICTIM	Reddit r/Scams user	PSEUDONYMOUS	Reported $35,000 loss to fake CNC Intelligence rep.	f	Reddit r/Scams	POSSIBLE	2026-08-26 19:31:43.995553+00
9	GFIN-CASE-001	INFRASTRUCTURE	NameCheap, Inc.	REGISTRAR	Domain registrar for cncintelinfo.com. Not complicit.	f	RDAP	CONFIRMED	2026-08-26 19:31:43.995913+00
10	GFIN-CASE-001	INFRASTRUCTURE	ProtonMail (Proton AG)	EMAIL_PROVIDER	Email provider. Swiss-based.	f	DNS MX records	CONFIRMED	2026-08-26 19:31:43.996198+00
11	GFIN-CASE-001	INFRASTRUCTURE	SEDO GmbH	HOSTING	Domain parking in Munich. Infrastructure lead only.	f	ipinfo.io	CONFIRMED	2026-08-26 19:31:43.996515+00
12	GFIN-CASE-001	INVESTIGATOR	GPT Luna (GFIN-CEA)	AI_AGENT	GFIN Chief Engineering Agent.	f	GFIN system	CONFIRMED	2026-08-26 19:31:43.996853+00
\.


--
-- Data for Name: police_officers; Type: TABLE DATA; Schema: public; Owner: gfin
--

COPY public.police_officers (id, email, name, role, agency, country_code, password_hash, badge_number, is_active, created_date, last_login, approved_by) FROM stdin;
1	admin@gfin-system.com	GFIN Admin	admin	GFIN Central	GB	004e3380a1fdb4b6cb100a4de48c7e16$2abefb02cbc3a06dd5aaca10c96a7a550b9cadc8e62ad957b45ab8fe266fa392		t	2026-08-26 20:21:05.202404+00	2026-08-26 22:29:20.015989+00	SYSTEM_AUTO
\.


--
-- Data for Name: scam_websites; Type: TABLE DATA; Schema: public; Owner: gfin
--

COPY public.scam_websites (id, domain, scam_type, risk_level, report_count, first_reported, last_reported, sources, evidence_hashes, description, status, target_type, related_domains, wallet_addresses, phone_numbers, countries_affected, total_loss_reported, is_verified, verified_by, verified_at, created_date, updated_date) FROM stdin;
1	cncintelinfo.com	RECOVERY_SCAM	CRITICAL	1	2026-08-26 20:42:00.87574+00	2026-08-26 20:42:00.87574+00	{investigation}	{}	Brand impersonation of CNC Intelligence - confirmed scam operation	ACTIVE	domain	\N	{}	{}	{GB,US,AU}	50000.00	f	\N	\N	2026-08-26 20:42:00.87574+00	2026-08-26 20:42:00.87574+00
2	recovery-funds-expert.com	RECOVERY_SCAM	HIGH	1	2026-08-26 20:42:00.88154+00	2026-08-26 20:42:00.88154+00	{monitor}	{}	Recovery scam website detected by proactive monitoring	ACTIVE	domain	\N	{}	{}	{}	0.00	f	\N	\N	2026-08-26 20:42:00.88154+00	2026-08-26 20:42:00.88154+00
3	crypto-retrieve.net	RECOVERY_SCAM	HIGH	1	2026-08-26 20:42:00.887013+00	2026-08-26 20:42:00.887013+00	{monitor}	{}	Fake crypto recovery service	ACTIVE	domain	\N	{}	{}	{}	0.00	f	\N	\N	2026-08-26 20:42:00.887013+00	2026-08-26 20:42:00.887013+00
\.


--
-- Data for Name: search_cache; Type: TABLE DATA; Schema: public; Owner: gfin
--

COPY public.search_cache (id, query_hash, query, results, connector, created_date, expires_at) FROM stdin;
\.


--
-- Data for Name: victim_complaints; Type: TABLE DATA; Schema: public; Owner: gfin
--

COPY public.victim_complaints (id, reference_number, victim_id, case_id, scam_type, target, incident_date, financial_loss, description, investigation_stage, country, auto_investigation_started, created_date, updated_date) FROM stdin;
\.


--
-- Data for Name: victim_notifications; Type: TABLE DATA; Schema: public; Owner: gfin
--

COPY public.victim_notifications (id, complaint_ref, victim_id, message, from_agency, is_read, created_date) FROM stdin;
\.


--
-- Data for Name: victim_sessions; Type: TABLE DATA; Schema: public; Owner: gfin
--

COPY public.victim_sessions (token, victim_id, created_date, expires_at) FROM stdin;
\.


--
-- Data for Name: victims; Type: TABLE DATA; Schema: public; Owner: gfin
--

COPY public.victims (id, email, name, password_hash, country, phone, is_verified, created_date) FROM stdin;
\.


--
-- Name: alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gfin
--

SELECT pg_catalog.setval('public.alerts_id_seq', 14, true);


--
-- Name: api_keys_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gfin
--

SELECT pg_catalog.setval('public.api_keys_id_seq', 1, false);


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gfin
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 29, true);


--
-- Name: cases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gfin
--

SELECT pg_catalog.setval('public.cases_id_seq', 5, true);


--
-- Name: complaint_files_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gfin
--

SELECT pg_catalog.setval('public.complaint_files_id_seq', 1, false);


--
-- Name: country_routing_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gfin
--

SELECT pg_catalog.setval('public.country_routing_id_seq', 189, true);


--
-- Name: evidence_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gfin
--

SELECT pg_catalog.setval('public.evidence_id_seq', 20, true);


--
-- Name: people_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gfin
--

SELECT pg_catalog.setval('public.people_id_seq', 12, true);


--
-- Name: police_officers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gfin
--

SELECT pg_catalog.setval('public.police_officers_id_seq', 1, true);


--
-- Name: scam_websites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gfin
--

SELECT pg_catalog.setval('public.scam_websites_id_seq', 3, true);


--
-- Name: search_cache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gfin
--

SELECT pg_catalog.setval('public.search_cache_id_seq', 1, false);


--
-- Name: victim_complaints_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gfin
--

SELECT pg_catalog.setval('public.victim_complaints_id_seq', 6, true);


--
-- Name: victim_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gfin
--

SELECT pg_catalog.setval('public.victim_notifications_id_seq', 3, true);


--
-- Name: victims_id_seq; Type: SEQUENCE SET; Schema: public; Owner: gfin
--

SELECT pg_catalog.setval('public.victims_id_seq', 6, true);


--
-- Name: alerts alerts_alert_id_key; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_alert_id_key UNIQUE (alert_id);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: cases cases_case_id_key; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_case_id_key UNIQUE (case_id);


--
-- Name: cases cases_pkey; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_pkey PRIMARY KEY (id);


--
-- Name: complaint_files complaint_files_pkey; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.complaint_files
    ADD CONSTRAINT complaint_files_pkey PRIMARY KEY (id);


--
-- Name: country_routing country_routing_country_code_key; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.country_routing
    ADD CONSTRAINT country_routing_country_code_key UNIQUE (country_code);


--
-- Name: country_routing country_routing_pkey; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.country_routing
    ADD CONSTRAINT country_routing_pkey PRIMARY KEY (id);


--
-- Name: evidence evidence_evidence_id_key; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.evidence
    ADD CONSTRAINT evidence_evidence_id_key UNIQUE (evidence_id);


--
-- Name: evidence evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.evidence
    ADD CONSTRAINT evidence_pkey PRIMARY KEY (id);


--
-- Name: people people_pkey; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.people
    ADD CONSTRAINT people_pkey PRIMARY KEY (id);


--
-- Name: police_officers police_officers_email_key; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.police_officers
    ADD CONSTRAINT police_officers_email_key UNIQUE (email);


--
-- Name: police_officers police_officers_pkey; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.police_officers
    ADD CONSTRAINT police_officers_pkey PRIMARY KEY (id);


--
-- Name: scam_websites scam_websites_domain_key; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.scam_websites
    ADD CONSTRAINT scam_websites_domain_key UNIQUE (domain);


--
-- Name: scam_websites scam_websites_pkey; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.scam_websites
    ADD CONSTRAINT scam_websites_pkey PRIMARY KEY (id);


--
-- Name: search_cache search_cache_pkey; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.search_cache
    ADD CONSTRAINT search_cache_pkey PRIMARY KEY (id);


--
-- Name: search_cache search_cache_query_hash_key; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.search_cache
    ADD CONSTRAINT search_cache_query_hash_key UNIQUE (query_hash);


--
-- Name: victim_complaints victim_complaints_pkey; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.victim_complaints
    ADD CONSTRAINT victim_complaints_pkey PRIMARY KEY (id);


--
-- Name: victim_complaints victim_complaints_reference_number_key; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.victim_complaints
    ADD CONSTRAINT victim_complaints_reference_number_key UNIQUE (reference_number);


--
-- Name: victim_notifications victim_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.victim_notifications
    ADD CONSTRAINT victim_notifications_pkey PRIMARY KEY (id);


--
-- Name: victim_sessions victim_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.victim_sessions
    ADD CONSTRAINT victim_sessions_pkey PRIMARY KEY (token);


--
-- Name: victims victims_email_key; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.victims
    ADD CONSTRAINT victims_email_key UNIQUE (email);


--
-- Name: victims victims_pkey; Type: CONSTRAINT; Schema: public; Owner: gfin
--

ALTER TABLE ONLY public.victims
    ADD CONSTRAINT victims_pkey PRIMARY KEY (id);


--
-- Name: idx_scam_sites_domain; Type: INDEX; Schema: public; Owner: gfin
--

CREATE INDEX idx_scam_sites_domain ON public.scam_websites USING btree (domain);


--
-- Name: idx_scam_sites_scam_type; Type: INDEX; Schema: public; Owner: gfin
--

CREATE INDEX idx_scam_sites_scam_type ON public.scam_websites USING btree (scam_type);


--
-- Name: idx_scam_sites_status; Type: INDEX; Schema: public; Owner: gfin
--

CREATE INDEX idx_scam_sites_status ON public.scam_websites USING btree (status);


--
-- PostgreSQL database dump complete
--

\unrestrict 62ZD04CUcag18hZX8pMLKEVnEo0gozHmg9XRpcJAcb9qW7zgD9sNFIX3NG4eAWT

